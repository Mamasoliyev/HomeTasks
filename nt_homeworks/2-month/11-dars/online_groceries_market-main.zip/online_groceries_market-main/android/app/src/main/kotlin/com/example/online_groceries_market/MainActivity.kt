package com.example.online_groceries_market

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
