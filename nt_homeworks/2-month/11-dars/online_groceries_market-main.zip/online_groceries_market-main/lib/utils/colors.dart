import 'package:flutter/material.dart';

class AppColors {
  static Color mainColor = Color(0xFF53B175);
  static Color mainGray = Color.fromARGB(255, 114, 114, 114);
  static Color mainBlack = Color(0xFF181725);
  static Color mainWhite = Color(0xFFFFFFFF);
}
