class AppMedia {
// images

  // static final String _baseImagePath = "assets/images";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String azizbekImagePath = "$_baseImagePath/azizbek.png";
  // static final String eggImagePath = "$_baseImagePath/egg.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/sprite.png";
  // static final String spriteImagePath = "$_baseImagePath/s.png";
  // static final String flagImagePath = "$_baseImagePath/flag.png";


}