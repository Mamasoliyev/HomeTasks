import 'dart:developer';

import 'package:flutter/material.dart';
import 'package:flutter_svg/flutter_svg.dart';
import 'package:online_groceries_market/screens/cart_screen.dart';
import 'package:online_groceries_market/screens/explore_screen.dart';
import 'package:online_groceries_market/screens/fav_screen.dart';
import 'package:online_groceries_market/screens/profile_screen.dart';
import 'package:online_groceries_market/screens/shop_screen.dart';
import 'package:online_groceries_market/utils/colors.dart';

class NavigationScreen extends StatefulWidget {
  const NavigationScreen({super.key});

  @override
  State<NavigationScreen> createState() => _NavigationScreenState();
}

class _NavigationScreenState extends State<NavigationScreen> {
  int selectectedIndex = 4;

  List<Widget> screens = [
    ShopScreen(),
    ExploreScreen(),
    CartScreen(),
    FavScreen(),
    ProfileScreen(),
  ];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: screens[selectectedIndex],
      bottomNavigationBar: Container(
        decoration: BoxDecoration(
          color: Colors.amber,
          borderRadius: BorderRadius.only(
            topRight: Radius.circular(30),
            topLeft: Radius.circular(30),
          ),
          boxShadow: [
            BoxShadow(color: Colors.black38, spreadRadius: 0, blurRadius: 10),
          ],
        ),
        child: ClipRRect(
          borderRadius: BorderRadius.only(
            topLeft: Radius.circular(30.0),
            topRight: Radius.circular(30.0),
          ),
          child: BottomNavigationBar(
            type: BottomNavigationBarType.shifting,
            onTap: (value) {
              log(value.toString());
              setState(() {
                selectectedIndex = value;
              });
            },
            selectedItemColor: AppColors.mainColor,
            unselectedItemColor: AppColors.mainBlack,
            showUnselectedLabels: true,
            showSelectedLabels: true,
            currentIndex: selectectedIndex,
            items: [
              BottomNavigationBarItem(
                label: "Shop",
                icon: SvgPicture.asset(
                  "assets/svgs/home.svg",
                  color:
                      selectectedIndex == 0
                          ? AppColors.mainColor
                          : AppColors.mainBlack,
                ),
              ),
              BottomNavigationBarItem(
                icon: SvgPicture.asset(
                  "assets/svgs/explore.svg",
                  color:
                      selectectedIndex == 1
                          ? AppColors.mainColor
                          : AppColors.mainBlack,
                ),

                label: "Explore",
              ),
              BottomNavigationBarItem(
                label: "Cart",

                icon: SvgPicture.asset(
                  "assets/svgs/cart.svg",

                  color:
                      selectectedIndex == 2
                          ? AppColors.mainColor
                          : AppColors.mainBlack,
                ),
              ),
              BottomNavigationBarItem(
                icon: SvgPicture.asset(
                  "assets/svgs/favorite.svg",
                  color:
                      selectectedIndex == 3
                          ? AppColors.mainColor
                          : AppColors.mainBlack,
                ),
                label: "Favorite",
              ),
              BottomNavigationBarItem(
                icon: SvgPicture.asset(
                  "assets/svgs/profile.svg",
                  color:
                      selectectedIndex == 4
                          ? AppColors.mainColor
                          : AppColors.mainBlack,
                ),
                label: "Profile",
              ),
            ],
          ),
        ),
      ),
    );
  }
}
