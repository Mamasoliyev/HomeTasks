import 'package:flutter/material.dart';

class AppColor {
  static Color textColorBlack = Color(0xff2F2F2F);
  static Color borderColor = Color(0xffD2D2D2);
  static Color textColor = Color(0xff888888);
  static Color whiteColor = Colors.white;
  static Color textcolorWhite = Color(0xffC5C5C5);
  static Color numberColor = Color(0xffCAC8C8);
  static Color splashScreenColor = Color(0xff006CAA);
  static Color splashScreenColor2 = Color(0xff002A5D);

}
