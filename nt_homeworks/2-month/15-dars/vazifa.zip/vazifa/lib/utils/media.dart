class Media {
  // Png
  static String basic = "assets/png";
  static String rasm = "$basic/rasm.png";
  static String mountain = "$basic/mountain.png";
  static String mountain2 = "$basic/mountain2.png";

  // Svg
  static String svgBasic = "assets/svg";
  static String vertikal = "$svgBasic/vertikal.svg";
  static String icon = "$svgBasic/icon.svg";
  static String location = "$svgBasic/location.svg";
  static String yulduzcha = "$svgBasic/yulduzcha.svg";
  static String yurecha = "$svgBasic/yurecha.svg";
  static String home = "$svgBasic/home.svg";
  static String user = "$svgBasic/user.svg";
  static String clock = "$svgBasic/clock.svg";
  static String heart = "$svgBasic/heart.svg";
  static String archive = "$svgBasic/archive.svg";
  static String clock2 = "$svgBasic/clock2.svg";
  static String bulut = "$svgBasic/bulut.svg";
  static String yulduzcha2 = "$svgBasic/yulduzcha2.svg";
  static String telegram = "$svgBasic/telegram.svg";
  static String splash_icon= "$svgBasic/splash_icon.svg";
}
