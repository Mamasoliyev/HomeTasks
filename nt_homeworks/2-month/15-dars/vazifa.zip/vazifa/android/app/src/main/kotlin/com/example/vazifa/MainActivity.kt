package com.example.vazifa

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
